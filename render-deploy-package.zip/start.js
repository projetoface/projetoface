// Importar o arquivo principal
require('./index.js');
